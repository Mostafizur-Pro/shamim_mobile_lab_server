export interface User {
  id?: number
  name: string
  image: string
  role: string
  number: string
  email: string
  password: string
  action: string
  created_at?: string
  updated_at?: string
}
