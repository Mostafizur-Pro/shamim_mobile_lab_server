import moment from "moment-timezone";

// export const formattedDate = moment.tz("Asia/Dhaka").format();
export const formattedDate = moment.tz("Asia/Dhaka").format('YYYY-MM-DD HH:mm:ss');